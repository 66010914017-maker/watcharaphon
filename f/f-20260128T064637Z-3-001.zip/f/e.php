<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>วัชรพล เวชแพทย์ (หนึ่ง)</title>
</head>

<body>
<h1> วัชรพล เวชแพทย์ (หนึ่ง) - while </h1>

<?php
$i = 1;
do {
	echo "$i : วัชรพล เวชแพทย์ (หนึ่ง) <br>" ; 
  	echo "<img src='1.jpg' width='250'><hr>";
  $i++;
} while ( $i<=10 );
?>

</body>
</html>