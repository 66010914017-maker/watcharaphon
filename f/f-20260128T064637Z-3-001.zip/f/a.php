<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>นายวัชรพล เวชแพทย์ (หนึ่ง)</title>
</head>

<body>
<h1>นายวัชรพล เวชแพทย์ (หนึ่ง) </h1>
<script language="javascript">
	document.write("คณะบัญชีและการจัดการ");
</script>
<br>

<?php
	echo "Wed Programming <br>";
    echo "Mahasarakham University <br>";
    print "Watcaraphon Wechaphaet <br>";
	
	$name = "วัชรพล เวชแพทย์";
	$age = 25.5 ;
	$Name = "วัชรพล";
	//echo gettype($age);
	var_dump($age);
	echo "<hr>";
	
	echo $name. "<br>";
	echo $Name. "<hr>";
	
	$a = 10;
	$b = 5;
	$c = 2;
	$x = $a / $b * $c ;
	echo $x;
?>

</body>
</html>
